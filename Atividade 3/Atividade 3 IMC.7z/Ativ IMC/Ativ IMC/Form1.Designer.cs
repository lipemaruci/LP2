﻿namespace Ativ_IMC
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.mskdtxtPESO = new System.Windows.Forms.MaskedTextBox();
            this.mskdtxtALTURA = new System.Windows.Forms.MaskedTextBox();
            this.txtIMC = new System.Windows.Forms.TextBox();
            this.LabelPeso = new System.Windows.Forms.Label();
            this.LabelAltura = new System.Windows.Forms.Label();
            this.LabelIMC = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(98, 360);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 0;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(335, 360);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 1;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(578, 360);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 2;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // mskdtxtPESO
            // 
            this.mskdtxtPESO.Location = new System.Drawing.Point(335, 67);
            this.mskdtxtPESO.Name = "mskdtxtPESO";
            this.mskdtxtPESO.Size = new System.Drawing.Size(100, 20);
            this.mskdtxtPESO.TabIndex = 3;
            this.mskdtxtPESO.Validated += new System.EventHandler(this.mskdtxtPESO_Validated);
            // 
            // mskdtxtALTURA
            // 
            this.mskdtxtALTURA.Location = new System.Drawing.Point(335, 158);
            this.mskdtxtALTURA.Name = "mskdtxtALTURA";
            this.mskdtxtALTURA.Size = new System.Drawing.Size(100, 20);
            this.mskdtxtALTURA.TabIndex = 4;
            this.mskdtxtALTURA.Validated += new System.EventHandler(this.mskdtxtALTURA_Validated);
            // 
            // txtIMC
            // 
            this.txtIMC.Location = new System.Drawing.Point(335, 262);
            this.txtIMC.Name = "txtIMC";
            this.txtIMC.Size = new System.Drawing.Size(100, 20);
            this.txtIMC.TabIndex = 5;
            // 
            // LabelPeso
            // 
            this.LabelPeso.AutoSize = true;
            this.LabelPeso.Location = new System.Drawing.Point(98, 67);
            this.LabelPeso.Name = "LabelPeso";
            this.LabelPeso.Size = new System.Drawing.Size(31, 13);
            this.LabelPeso.TabIndex = 6;
            this.LabelPeso.Text = "Peso";
            // 
            // LabelAltura
            // 
            this.LabelAltura.AutoSize = true;
            this.LabelAltura.Location = new System.Drawing.Point(98, 158);
            this.LabelAltura.Name = "LabelAltura";
            this.LabelAltura.Size = new System.Drawing.Size(34, 13);
            this.LabelAltura.TabIndex = 7;
            this.LabelAltura.Text = "Altura";
            // 
            // LabelIMC
            // 
            this.LabelIMC.AutoSize = true;
            this.LabelIMC.Location = new System.Drawing.Point(98, 262);
            this.LabelIMC.Name = "LabelIMC";
            this.LabelIMC.Size = new System.Drawing.Size(26, 13);
            this.LabelIMC.TabIndex = 8;
            this.LabelIMC.Text = "IMC";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LabelIMC);
            this.Controls.Add(this.LabelAltura);
            this.Controls.Add(this.LabelPeso);
            this.Controls.Add(this.txtIMC);
            this.Controls.Add(this.mskdtxtALTURA);
            this.Controls.Add(this.mskdtxtPESO);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalcular);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.MaskedTextBox mskdtxtPESO;
        private System.Windows.Forms.MaskedTextBox mskdtxtALTURA;
        private System.Windows.Forms.TextBox txtIMC;
        private System.Windows.Forms.Label LabelPeso;
        private System.Windows.Forms.Label LabelAltura;
        private System.Windows.Forms.Label LabelIMC;
    }
}

