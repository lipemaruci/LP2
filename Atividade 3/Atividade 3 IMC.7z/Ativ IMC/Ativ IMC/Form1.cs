﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ativ_IMC
{
    public partial class Form1 : Form
    {
        double peso, altura, IMC;

        private void mskdtxtPESO_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(mskdtxtPESO.Text, out peso)) || (peso <= 0))
            {
                MessageBox.Show("peso inválido");
                mskdtxtPESO.Focus();
            }
        }

        private void mskdtxtALTURA_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(mskdtxtALTURA.Text, out altura)) || (altura <= 0))
            {
                MessageBox.Show("altura inválida");
                mskdtxtALTURA.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskdtxtPESO.Clear();
            mskdtxtALTURA.Clear();
            txtIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = peso / (altura * altura);
            IMC = Math.Round(IMC, 1);

            txtIMC.Text = IMC.ToString();
            if (IMC < 18.5)
            {
                MessageBox.Show("Magreza");
            }
            else if (IMC <= 24.9)
            {
                MessageBox.Show("Normal");
            }
            else if (IMC <= 29.9)
            {
                MessageBox.Show("Sobrepeso");
            }
            else if (IMC <= 39.9)
            {
                MessageBox.Show("Obesidade");
            }
            else
            {
                MessageBox.Show("Obesidade grave");
            }
        }
    }
}
