﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PReava
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lstBx1.Items.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[] A = new double[10];
            double[] B = new double[10];

            A[0] = 1.50;
            A[1] = 2.50;
            A[2] = 3.50;
            A[3] = 4.50;
            A[4] = 5.50;
            A[5] = 6.50;
            A[6] = 7.50;
            A[7] = 8.50;
            A[8] = 9.50;
            A[9] = 10.50;

            for (int i = 0; i < 10 ; i++)
            { 
                
                if (!(i % 2 ==0))
                {
                    B[i] = A[i] + 4;

                }

 
                else {

                    B[i] = A[i] * 4;
                }

                lstBx1.Items.Add($"Posição: {i.ToString()} Matriz A = {A[i].ToString("N2")} Matriz B = {B[i].ToString("N2")}");

            }
        }
    }
}
