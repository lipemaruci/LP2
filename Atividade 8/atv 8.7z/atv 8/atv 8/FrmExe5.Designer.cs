﻿namespace atv_8
{
    partial class FrmExe5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalc5 = new System.Windows.Forms.Button();
            this.listExe5 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnCalc5
            // 
            this.btnCalc5.Location = new System.Drawing.Point(77, 67);
            this.btnCalc5.Name = "btnCalc5";
            this.btnCalc5.Size = new System.Drawing.Size(198, 100);
            this.btnCalc5.TabIndex = 0;
            this.btnCalc5.Text = "Calcule";
            this.btnCalc5.UseVisualStyleBackColor = true;
            this.btnCalc5.Click += new System.EventHandler(this.btnCalc5_Click);
            // 
            // listExe5
            // 
            this.listExe5.FormattingEnabled = true;
            this.listExe5.Location = new System.Drawing.Point(435, 12);
            this.listExe5.Name = "listExe5";
            this.listExe5.Size = new System.Drawing.Size(353, 420);
            this.listExe5.TabIndex = 1;
            // 
            // FrmExe5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listExe5);
            this.Controls.Add(this.btnCalc5);
            this.Name = "FrmExe5";
            this.Text = "FrmExe5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCalc5;
        private System.Windows.Forms.ListBox listExe5;
    }
}