﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atv_8
{
    public partial class FrmExe5 : Form
    {
        public FrmExe5()
        {
            InitializeComponent();
        }

        private void btnCalc5_Click(object sender, EventArgs e)
        {
            int N = 6;
            int Q = 10;
            string[] gabarito = {"A", "B", "C", "D", "E"};
            string[,] respAlunos = new string[N, Q];
            string auxiliar;

            for(int i = 0; i < N; i++)
            {
                auxiliar = Interaction.InputBox($"Aluno {i + 1}:");

                for(int j = 0; j < Q; j++)
                {

                }

            }

        }
    }
}
