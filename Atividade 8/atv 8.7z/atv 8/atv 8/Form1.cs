﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace atv_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otavio", "Marcelo", "Pedro", "Thais" };
            string aux = "";

            foreach (string x in lista)
            {
                aux += x + "\n";
            }
            MessageBox.Show(aux);

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEXE1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("Digite um numero", "Entrada de dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Numero invalido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
            {
                auxiliar += x + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnEXE3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double media = 0;
            double soma = 0;
            string auxiliar = "";

            for (var i = 0; i < 20; i++)
            {
                for (var j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do Aluno {i + 1}", "Entrada de dados");
                    if (!double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Numero invalido");
                        j--;
                    }
                    soma += notas[i,j];
                }
                media = soma / 3.0;
                MessageBox.Show($"Aluno{i + 1}: Média{media.ToString("N2")}");
                media = 0;
                soma = 0;
            }

        }

        private void btnEXE4_Click(object sender, EventArgs e)
        {
            FrmExe4 frmExe4 = new FrmExe4();
            frmExe4.Show();

            
        }

        private void btnEXE5_Click(object sender, EventArgs e)
        {
            FrmExe5 frmExe5 = new FrmExe5();
            frmExe5.Show();
        }
    }
}
