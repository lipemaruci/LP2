﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atv_8
{
    public partial class FrmExe4 : Form
    {
        public FrmExe4()
        {
            InitializeComponent();
        }

        private void btnComp_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] comprimento = new int[10];

            for (int i = 0; i < 10; i++)
            {
                string nome = Interaction.InputBox($"Digite o nome completo da pessoa {i + 1}:", "Entrada de dados");
                nomes[i] = nome;

                int espbra = nome.Replace(" ", "").Length;
                comprimento[i] = espbra;
            }
            listBoxResultado.Items.Clear();
            for (int j = 0; j < 10; j++)
            {
                listBoxResultado.Items.Add($"Nome: {nomes[j]} tem {comprimento[j]} caracteres");
            }

        }


        private void listBoxResultado_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
