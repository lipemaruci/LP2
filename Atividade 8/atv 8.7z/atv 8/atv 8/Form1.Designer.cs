﻿namespace atv_8
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEXE2 = new System.Windows.Forms.Button();
            this.btnEXE3 = new System.Windows.Forms.Button();
            this.btnEXE1 = new System.Windows.Forms.Button();
            this.btnEXE4 = new System.Windows.Forms.Button();
            this.btnEXE5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnEXE2
            // 
            this.btnEXE2.Location = new System.Drawing.Point(459, 27);
            this.btnEXE2.Name = "btnEXE2";
            this.btnEXE2.Size = new System.Drawing.Size(232, 92);
            this.btnEXE2.TabIndex = 0;
            this.btnEXE2.Text = "exercicio 2";
            this.btnEXE2.UseVisualStyleBackColor = true;
            this.btnEXE2.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnEXE3
            // 
            this.btnEXE3.Location = new System.Drawing.Point(133, 173);
            this.btnEXE3.Name = "btnEXE3";
            this.btnEXE3.Size = new System.Drawing.Size(225, 92);
            this.btnEXE3.TabIndex = 1;
            this.btnEXE3.Text = "exercicio 3";
            this.btnEXE3.UseVisualStyleBackColor = true;
            this.btnEXE3.Click += new System.EventHandler(this.btnEXE3_Click);
            // 
            // btnEXE1
            // 
            this.btnEXE1.Location = new System.Drawing.Point(126, 27);
            this.btnEXE1.Name = "btnEXE1";
            this.btnEXE1.Size = new System.Drawing.Size(232, 92);
            this.btnEXE1.TabIndex = 2;
            this.btnEXE1.Text = "exercicio 1";
            this.btnEXE1.UseVisualStyleBackColor = true;
            this.btnEXE1.Click += new System.EventHandler(this.btnEXE1_Click);
            // 
            // btnEXE4
            // 
            this.btnEXE4.Location = new System.Drawing.Point(459, 173);
            this.btnEXE4.Name = "btnEXE4";
            this.btnEXE4.Size = new System.Drawing.Size(232, 92);
            this.btnEXE4.TabIndex = 3;
            this.btnEXE4.Text = "exercicio 4";
            this.btnEXE4.UseVisualStyleBackColor = true;
            this.btnEXE4.Click += new System.EventHandler(this.btnEXE4_Click);
            // 
            // btnEXE5
            // 
            this.btnEXE5.Location = new System.Drawing.Point(283, 296);
            this.btnEXE5.Name = "btnEXE5";
            this.btnEXE5.Size = new System.Drawing.Size(232, 92);
            this.btnEXE5.TabIndex = 4;
            this.btnEXE5.Text = "exercicio 5";
            this.btnEXE5.UseVisualStyleBackColor = true;
            this.btnEXE5.Click += new System.EventHandler(this.btnEXE5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnEXE5);
            this.Controls.Add(this.btnEXE4);
            this.Controls.Add(this.btnEXE1);
            this.Controls.Add(this.btnEXE3);
            this.Controls.Add(this.btnEXE2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEXE2;
        private System.Windows.Forms.Button btnEXE3;
        private System.Windows.Forms.Button btnEXE1;
        private System.Windows.Forms.Button btnEXE4;
        private System.Windows.Forms.Button btnEXE5;
    }
}

