﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_4__Triangulo
{
    public partial class Form1 : Form
    {
        double lado1, lado2, lado3;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskdLado1.Clear();
            mskdLado2.Clear(); 
            mskdLado3.Clear();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();

        }

        private void mskdLado1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskdLado1.Text, out lado1))
            {
                MessageBox.Show("lado invalido");
                mskdLado1.Focus();
            }
            else
            {
                if (lado1 == 0)
                {
                    MessageBox.Show("O numero deve ser maior que 0");
                    mskdLado1.Focus();
                }
            }
        }

        private void mskdLado2_Validated(object sender, EventArgs e)
        {
                if (!double.TryParse(mskdLado2.Text, out lado2))
                {
                    MessageBox.Show("lado invalido");
                    mskdLado2.Focus();
                }
                else
                {
                    if (lado2 == 0)
                    {
                        MessageBox.Show("O numero deve ser maior que 0");
                        mskdLado2.Focus();
                    }
                }
        }

        private void mskdLado3_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskdLado3.Text, out lado3))
            {
                MessageBox.Show("lado invalido");
                mskdLado3.Focus();
            }
            else
            {
                if (lado3 == 0)
                {
                    MessageBox.Show("O numero deve ser maior que 0");
                    mskdLado3.Focus();
                }
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((lado1 < lado2 + lado3) && (lado1> Math.Abs(lado2-lado3)) && (lado2 < lado1 + lado3) && (lado3 < lado1 + lado2)) 
            {
                if ((lado1 == lado2) && (lado2 == lado3))
                {
                    MessageBox.Show("Trinagulo equilatero");
                }


            else if ((lado1 == lado2) || (lado2 == lado3))
                {
                    MessageBox.Show("Triangulo isoceles");
                }
            else
                {
                    MessageBox.Show("Triangulo escaleno");
                }
            }
            else
            {
                MessageBox.Show("Não é um triangulo");
            }
        }

    }
}
